
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.amod.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.amod.item.ShittItem;
import net.amod.item.RickRolldItem;
import net.amod.item.NightItem;
import net.amod.item.DynamiteItem;
import net.amod.item.DrippyCheezeItem;
import net.amod.item.DayItem;
import net.amod.AModMod;

public class AModModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(AModMod.MODID);
	public static final DeferredItem<Item> SHITT = REGISTRY.register("shitt", ShittItem::new);
	public static final DeferredItem<Item> DA_VOID = block(AModModBlocks.DA_VOID);
	public static final DeferredItem<Item> DRIPPY_CHEEZE = REGISTRY.register("drippy_cheeze", DrippyCheezeItem::new);
	public static final DeferredItem<Item> RICK_ROLLD = REGISTRY.register("rick_rolld", RickRolldItem::new);
	public static final DeferredItem<Item> DYNAMITE = REGISTRY.register("dynamite", DynamiteItem::new);
	public static final DeferredItem<Item> DAY = REGISTRY.register("day", DayItem::new);
	public static final DeferredItem<Item> NIGHT = REGISTRY.register("night", NightItem::new);

	// Start of user code block custom items
	// End of user code block custom items
	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties()));
	}
}
