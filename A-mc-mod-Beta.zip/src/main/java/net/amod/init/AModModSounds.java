
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.amod.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.Registries;

import net.amod.AModMod;

public class AModModSounds {
	public static final DeferredRegister<SoundEvent> REGISTRY = DeferredRegister.create(Registries.SOUND_EVENT, AModMod.MODID);
	public static final DeferredHolder<SoundEvent, SoundEvent> DRIPPY_CHEESE = REGISTRY.register("drippy_cheese", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("a_mod", "drippy_cheese")));
	public static final DeferredHolder<SoundEvent, SoundEvent> RICKROLL = REGISTRY.register("rickroll", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("a_mod", "rickroll")));
	public static final DeferredHolder<SoundEvent, SoundEvent> THICC = REGISTRY.register("thicc", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("a_mod", "thicc")));
}
