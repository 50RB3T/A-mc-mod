
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.amod.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;

import net.amod.AModMod;

public class AModModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, AModMod.MODID);
	public static final DeferredHolder<CreativeModeTab, CreativeModeTab> S_HEE_E_EE_SH = REGISTRY.register("s_hee_e_ee_sh",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.a_mod.s_hee_e_ee_sh")).icon(() -> new ItemStack(Items.MUSIC_DISC_11)).displayItems((parameters, tabData) -> {
				tabData.accept(AModModItems.DAY.get());
				tabData.accept(AModModItems.NIGHT.get());
				tabData.accept(AModModBlocks.DA_VOID.get().asItem());
				tabData.accept(AModModItems.SHITT.get());
				tabData.accept(AModModItems.DRIPPY_CHEEZE.get());
				tabData.accept(AModModItems.RICK_ROLLD.get());
				tabData.accept(AModModItems.DYNAMITE.get());
			}).withSearchBar().build());
}
